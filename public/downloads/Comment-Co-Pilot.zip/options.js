async function load() {
  const { geminiApiKey, geminiModel } = await chrome.storage.local.get(['geminiApiKey', 'geminiModel']);
  if (geminiApiKey) document.getElementById('api-key').value = geminiApiKey;
  document.getElementById('model-name').value = geminiModel || 'gemini-3.1-flash-lite';
}

document.getElementById('save-btn').addEventListener('click', async () => {
  const key = document.getElementById('api-key').value.trim();
  await chrome.storage.local.set({ geminiApiKey: key });
  const msg = document.getElementById('saved-msg');
  msg.style.display = 'inline';
  setTimeout(() => { msg.style.display = 'none'; }, 1500);
});

document.getElementById('save-model-btn').addEventListener('click', async () => {
  const model = document.getElementById('model-name').value.trim() || 'gemini-2.5-flash';
  await chrome.storage.local.set({ geminiModel: model });
  alert('Model saved: ' + model);
});

load();
