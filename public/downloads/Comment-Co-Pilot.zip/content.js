// ============================================================================
// LinkedIn Comment Co-Pilot — content script
//
// LinkedIn's CSS classes are machine-generated and hashed per build (e.g.
// "bghmnt bghmns bghr4") — they carry no meaning and WILL change again
// without notice. Every selector below is chosen to avoid class names
// entirely wherever possible, in this order of preference:
//   1. ARIA roles/labels (role="listitem", aria-label="Comment") — required
//      for accessibility, least likely to change.
//   2. data-testid substrings — LinkedIn's own QA hooks, also durable.
//   3. DOM structure relative to #1/#2 (e.g. "the comment button's parent").
//   4. Legacy class-name selectors, kept ONLY as a last-resort fallback in
//      case a page variant still uses them.
//
// If the button stops appearing again, open DevTools -> Console (DEBUG logs
// are on by default) to see what was/wasn't found, verify live against
// LinkedIn with the same probing approach, then update CONFIG here.
// Last verified against live linkedin.com/feed: 2026-10-01.
// ============================================================================

const CONFIG = {
  DEBUG: true,

  // A post is any div[role="listitem"] that contains a Comment button.
  // (role="listitem" alone also matches non-post feed modules like "People
  // you may know" — the Comment-button check is what narrows it to posts.)
  POST_CONTAINER_SELECTOR: 'div[role="listitem"]',
  COMMENT_BUTTON_SELECTOR: 'button[aria-label^="Comment"]',

  // Legacy fallbacks — unlikely to match anymore, cost nothing to keep.
  LEGACY_POST_CONTAINER_SELECTORS: [
    'div.feed-shared-update-v2',
    'div[data-urn][class*="feed-shared-update"]',
    'div.occludable-update'
  ],
  LEGACY_ACTION_BAR_SELECTORS: [
    '.feed-shared-social-action-bar',
    '.social-actions-bar',
    '[class*="social-action"]'
  ],

  POST_TEXT_SELECTOR: '[data-testid="expandable-text-box"]',
  LEGACY_POST_TEXT_SELECTORS: [
    '.feed-shared-update-v2__description .update-components-text',
    '.update-components-text',
    '[data-test-id="main-feed-activity-card__commentary"]'
  ],

  // The per-post comment list container's data-testid is dynamically
  // generated (e.g. "CgsIgMC...-commentList...FeedType_MAIN_FEED") but
  // always contains the literal substring "commentList".
  COMMENT_LIST_TESTID_SUBSTRING: 'commentList',
  LEGACY_COMMENT_ITEM_SELECTORS: [
    '.comments-comment-item',
    '[class*="comments-comment-item"]'
  ],

  // LinkedIn's real comment editor, confirmed live. Legacy Quill-based
  // editors from older page variants are kept as a fallback.
  COMMENT_EDITOR_SELECTORS: [
    'div[role="textbox"][aria-label="Text editor for creating comment"][contenteditable="true"]',
    '.ql-editor[contenteditable="true"]',
    'div[role="textbox"][contenteditable="true"]'
  ],

  PROFILE_ABOUT_HEADINGS: ['About'],
  PROFILE_EXPERIENCE_HEADINGS: ['Experience'],

  MAX_COMMENTS_TO_READ: 8,
  MAX_IMAGES: 6,
  MIN_IMAGE_WIDTH: 150,
  PROFILE_CACHE_MAX_AGE_MS: 30 * 24 * 60 * 60 * 1000 // 30 days
};

function log(...args) {
  if (CONFIG.DEBUG) console.log('[LI Comment Co-Pilot]', ...args);
}

function firstMatch(root, selectors) {
  for (const sel of selectors) {
    const el = root.querySelector(sel);
    if (el) return el;
  }
  return null;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

// ----------------------------------------------------------------------------
// Profile capture ("your voice")
// ----------------------------------------------------------------------------

function isProfilePage() {
  return /^\/in\//.test(location.pathname);
}

function extractSectionText(headingCandidates) {
  const headings = Array.from(document.querySelectorAll('h2, h3'));
  const heading = headings.find(h => {
    const t = (h.innerText || '').trim().toLowerCase();
    return headingCandidates.some(c => t.startsWith(c.toLowerCase()));
  });
  if (!heading) return '';
  const section = heading.closest('section') || heading.parentElement?.parentElement || heading.parentElement;
  return section ? section.innerText.trim().slice(0, 2000) : '';
}

async function captureProfile() {
  const nameEl = document.querySelector('h1');
  const name = nameEl?.innerText?.trim() || '';

  let headline = '';
  if (nameEl) {
    const sibling = nameEl.parentElement?.nextElementSibling;
    headline = sibling?.innerText?.trim() || '';
  }

  const about = extractSectionText(CONFIG.PROFILE_ABOUT_HEADINGS);
  const experience = extractSectionText(CONFIG.PROFILE_EXPERIENCE_HEADINGS);

  const profile = { name, headline, about, experience, capturedAt: Date.now() };
  await chrome.storage.local.set({ voiceProfile: profile });
  log('Captured profile', profile);
  return profile;
}

// Exposed so the popup can trigger a re-scan via chrome.scripting.executeScript
window.__lccCaptureProfile = captureProfile;

(async function autoCaptureIfStale() {
  if (!isProfilePage()) return;
  const { voiceProfile } = await chrome.storage.local.get('voiceProfile');
  const stale = !voiceProfile || (Date.now() - (voiceProfile.capturedAt || 0) > CONFIG.PROFILE_CACHE_MAX_AGE_MS);
  if (stale) {
    setTimeout(() => captureProfile().catch(e => log('auto profile capture failed', e)), 1500);
  }
})();

// ----------------------------------------------------------------------------
// Post scanning + button injection
// ----------------------------------------------------------------------------

const processedPosts = new WeakSet();

function findPosts() {
  const candidates = document.querySelectorAll(CONFIG.POST_CONTAINER_SELECTOR);
  const posts = Array.from(candidates).filter(el => el.querySelector(CONFIG.COMMENT_BUTTON_SELECTOR));
  if (posts.length === 0) {
    // Fall back to legacy class-based containers in case this page variant
    // still uses them.
    return Array.from(document.querySelectorAll(CONFIG.LEGACY_POST_CONTAINER_SELECTORS.join(',')));
  }
  return posts;
}

function getActionRow(post) {
  const commentBtn = post.querySelector(CONFIG.COMMENT_BUTTON_SELECTOR);
  if (commentBtn?.parentElement) return commentBtn.parentElement;
  return firstMatch(post, CONFIG.LEGACY_ACTION_BAR_SELECTORS);
}

function scanForPosts() {
  const posts = findPosts();
  posts.forEach(post => {
    if (processedPosts.has(post)) return;
    processedPosts.add(post);
    injectDraftButton(post);
  });
}

function injectDraftButton(post) {
  const actionRow = getActionRow(post);
  if (!actionRow) {
    log('No action row found for a post — skipping button injection', post);
    return;
  }
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'lcc-draft-btn';
  btn.textContent = '✎ Draft comment';
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    handleDraftClick(post, btn);
  });
  actionRow.appendChild(btn);
}

const observer = new MutationObserver(() => scanForPosts());
observer.observe(document.body, { childList: true, subtree: true });
scanForPosts();

// ----------------------------------------------------------------------------
// Extraction
// ----------------------------------------------------------------------------

async function fetchAsBase64InPage(url, forceMime) {
  const res = await fetch(url);
  const blob = await res.blob();
  const mimeType = forceMime || blob.type || 'application/octet-stream';
  const data = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
  return { mimeType, data };
}

function extractPostText(post) {
  const textEl = post.querySelector(CONFIG.POST_TEXT_SELECTOR) || firstMatch(post, CONFIG.LEGACY_POST_TEXT_SELECTORS);
  // Use textContent, not innerText: LinkedIn keeps the full post text in the
  // DOM even when visually clipped behind a "...more" toggle, and
  // textContent reads it regardless of that CSS clamping. innerText would
  // risk returning only the truncated, visible portion.
  if (textEl) return textEl.textContent.trim();
  return post.textContent?.trim().slice(0, 1000) || '';
}

function extractComments(post) {
  // Find this post's comment list: a descendant whose data-testid contains
  // "commentList" (the rest of the id is a per-post generated hash).
  const commentListEl = Array.from(post.querySelectorAll('[data-testid]'))
    .find(el => (el.getAttribute('data-testid') || '').includes(CONFIG.COMMENT_LIST_TESTID_SUBSTRING));

  if (commentListEl) {
    const items = Array.from(commentListEl.children)
      .map(c => c.textContent.trim())
      .filter(t => t.length > 10); // drop spacer/divider divs with no real content
    if (items.length) return items.slice(0, CONFIG.MAX_COMMENTS_TO_READ);
  }

  // Legacy fallback.
  const legacyItems = Array.from(post.querySelectorAll(CONFIG.LEGACY_COMMENT_ITEM_SELECTORS.join(',')))
    .slice(0, CONFIG.MAX_COMMENTS_TO_READ);
  return legacyItems.map(c => c.innerText.trim()).filter(Boolean);
}

async function extractPost(post) {
  const text = extractPostText(post);

  const imgEls = Array.from(post.querySelectorAll('img')).filter(img => {
    const w = img.naturalWidth || img.width || 0;
    return w >= CONFIG.MIN_IMAGE_WIDTH && !/profile-displayphoto|ghost-person|company-logo/i.test(img.src || '');
  });
  const imageUrls = [...new Set(imgEls.map(i => i.src))].slice(0, CONFIG.MAX_IMAGES);

  // Video: if it's a blob: URL it only exists in this document, so we must
  // read it here in the content script. Regular https URLs get handed to the
  // background worker, which can fetch cross-origin without CORS trouble.
  let videoInline = null;
  let videoUrl = null;
  let posterUrl = null;

  const videoEl = post.querySelector('video');
  if (videoEl) {
    const src = videoEl.currentSrc || videoEl.src || '';
    posterUrl = videoEl.poster || null;
    if (src.startsWith('blob:')) {
      videoInline = await fetchAsBase64InPage(src, 'video/mp4').catch((e) => {
        log('Could not read blob video in-page', e);
        return null;
      });
    } else if (src) {
      videoUrl = src;
    }
  }

  const comments = extractComments(post);

  const extracted = { text, imageUrls, videoInline, videoUrl, posterUrl, comments };
  log('Extracted post', extracted);
  return extracted;
}

// ----------------------------------------------------------------------------
// Draft flow
// ----------------------------------------------------------------------------

async function handleDraftClick(post, btn) {
  const originalText = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'Reading post…';
  try {
    const extracted = await extractPost(post);
    const { voiceProfile } = await chrome.storage.local.get('voiceProfile');

    btn.textContent = 'Drafting…';
    const response = await chrome.runtime.sendMessage({
      type: 'DRAFT_COMMENTS',
      payload: { post: extracted, voiceProfile: voiceProfile || null }
    });

    if (response?.error) {
      showError(post, response.error);
    } else {
      showDraftPanel(post, response);
    }
  } catch (err) {
    console.error('[LI Comment Co-Pilot]', err);
    showError(post, err.message || String(err));
  } finally {
    btn.disabled = false;
    btn.textContent = originalText;
  }
}

function removeExistingPanel(post) {
  post.querySelectorAll('[data-lcc-panel]').forEach(el => el.remove());
}

function showError(post, message) {
  removeExistingPanel(post);
  const err = document.createElement('div');
  err.className = 'lcc-error';
  err.dataset.lccPanel = 'true';
  err.textContent = 'Comment Co-Pilot: ' + message;
  post.appendChild(err);
}

function flashCopied(card) {
  const btn = card.querySelector('.lcc-copy-btn');
  const original = btn.textContent;
  btn.textContent = 'Copied ✓';
  setTimeout(() => { btn.textContent = original; }, 1200);
}

function showDraftPanel(post, response) {
  removeExistingPanel(post);

  const panel = document.createElement('div');
  panel.className = 'lcc-panel';
  panel.dataset.lccPanel = 'true';
  panel.innerHTML = `
    <div class="lcc-panel-header">
      <span class="lcc-panel-title">Draft comment</span>
      <button type="button" class="lcc-panel-close" aria-label="Close">×</button>
    </div>
    ${response.analysis ? `<div class="lcc-analysis">${escapeHtml(response.analysis)}</div>` : ''}
    <div class="lcc-drafts"></div>
  `;

  const draftsWrap = panel.querySelector('.lcc-drafts');
  (response.drafts || []).forEach((d, i) => {
    const card = document.createElement('div');
    card.className = 'lcc-draft-card';
    card.innerHTML = `
      <div class="lcc-draft-label">${escapeHtml(d.strategy || `Option ${i + 1}`)}</div>
      <div class="lcc-draft-text" contenteditable="true">${escapeHtml(d.text)}</div>
      <div class="lcc-draft-actions">
        <button type="button" class="lcc-insert-btn">Insert into comment box</button>
        <button type="button" class="lcc-copy-btn">Copy</button>
      </div>
    `;
    card.querySelector('.lcc-insert-btn').addEventListener('click', () => {
      const finalText = card.querySelector('.lcc-draft-text').innerText;
      insertIntoCommentBox(post, finalText);
    });
    card.querySelector('.lcc-copy-btn').addEventListener('click', () => {
      const finalText = card.querySelector('.lcc-draft-text').innerText;
      navigator.clipboard.writeText(finalText);
      flashCopied(card);
    });
    draftsWrap.appendChild(card);
  });

  panel.querySelector('.lcc-panel-close').addEventListener('click', () => panel.remove());
  post.appendChild(panel);
}

async function insertIntoCommentBox(post, text) {
  const editor = firstMatch(post, CONFIG.COMMENT_EDITOR_SELECTORS);

  if (!editor) {
    // LinkedIn's comment editor only appears after a REAL, trusted click on
    // its Comment button — a script-dispatched click (even a full
    // pointerdown/mousedown/mouseup/click sequence) does not open it. That
    // means this extension cannot auto-open the box itself; it can only
    // fill one that's already open. Ask the person to open it first rather
    // than silently failing or pretending to have inserted the text.
    alert('Comment Co-Pilot: click LinkedIn\'s own "Comment" button on this post first to open the comment box, then click Insert again. (LinkedIn only opens it for a real click, which this extension can\'t simulate.)');
    return;
  }

  editor.focus();
  const inserted = document.execCommand('insertText', false, text);
  if (!inserted) {
    // Fallback for editors that ignore execCommand entirely.
    editor.textContent = text;
    editor.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }));
  }
}
