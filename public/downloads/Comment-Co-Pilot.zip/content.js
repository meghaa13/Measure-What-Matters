// ============================================================================
// LinkedIn Comment Co-Pilot — content script
//
// LinkedIn's DOM uses obfuscated, frequently-changing class names and differs
// slightly by account/locale/post-type. Every selector list below is ordered
// "most specific first" with fallbacks. If a button doesn't appear, or text/
// comments come back empty, open DevTools -> Console (DEBUG logs are on by
// default) to see what was/wasn't found, then add a selector here.
// ============================================================================

const CONFIG = {
  DEBUG: true,

  POST_CONTAINER_SELECTORS: [
    'div.feed-shared-update-v2',
    'div[data-urn][class*="feed-shared-update"]',
    'div.occludable-update'
  ],
  ACTION_BAR_SELECTORS: [
    '.feed-shared-social-action-bar',
    '.social-actions-bar',
    '[class*="social-action"]'
  ],
  COMMENT_BUTTON_SELECTORS: [
    'button[aria-label*="Comment"]'
  ],
  POST_TEXT_SELECTORS: [
    '.feed-shared-update-v2__description .update-components-text',
    '.update-components-text',
    '[data-test-id="main-feed-activity-card__commentary"]'
  ],
  COMMENT_ITEM_SELECTORS: [
    '.comments-comment-item',
    '[class*="comments-comment-item"]'
  ],
  COMMENT_EDITOR_SELECTORS: [
    '.ql-editor[contenteditable="true"]',
    'div[role="textbox"][contenteditable="true"]'
  ],
  PROFILE_ABOUT_HEADINGS: ['About'],
  PROFILE_EXPERIENCE_HEADINGS: ['Experience'],

  MAX_COMMENTS_TO_READ: 8,
  MAX_IMAGES: 6,
  MIN_IMAGE_WIDTH: 150,
  PROFILE_CACHE_MAX_AGE_MS: 30 * 24 * 60 * 60 * 1000 // 30 days
};

function log(...args) {
  if (CONFIG.DEBUG) console.log('[LI Comment Co-Pilot]', ...args);
}

function firstMatch(root, selectors) {
  for (const sel of selectors) {
    const el = root.querySelector(sel);
    if (el) return el;
  }
  return null;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

// ----------------------------------------------------------------------------
// Profile capture ("your voice")
// ----------------------------------------------------------------------------

function isProfilePage() {
  return /^\/in\//.test(location.pathname);
}

function extractSectionText(headingCandidates) {
  const headings = Array.from(document.querySelectorAll('h2, h3'));
  const heading = headings.find(h => {
    const t = (h.innerText || '').trim().toLowerCase();
    return headingCandidates.some(c => t.startsWith(c.toLowerCase()));
  });
  if (!heading) return '';
  const section = heading.closest('section') || heading.parentElement?.parentElement || heading.parentElement;
  return section ? section.innerText.trim().slice(0, 2000) : '';
}

async function captureProfile() {
  const nameEl = document.querySelector('h1');
  const name = nameEl?.innerText?.trim() || '';

  let headline = '';
  if (nameEl) {
    const sibling = nameEl.parentElement?.nextElementSibling;
    headline = sibling?.innerText?.trim() || '';
  }

  const about = extractSectionText(CONFIG.PROFILE_ABOUT_HEADINGS);
  const experience = extractSectionText(CONFIG.PROFILE_EXPERIENCE_HEADINGS);

  const profile = { name, headline, about, experience, capturedAt: Date.now() };
  await chrome.storage.local.set({ voiceProfile: profile });
  log('Captured profile', profile);
  return profile;
}

// Exposed so the popup can trigger a re-scan via chrome.scripting.executeScript
window.__lccCaptureProfile = captureProfile;

(async function autoCaptureIfStale() {
  if (!isProfilePage()) return;
  const { voiceProfile } = await chrome.storage.local.get('voiceProfile');
  const stale = !voiceProfile || (Date.now() - (voiceProfile.capturedAt || 0) > CONFIG.PROFILE_CACHE_MAX_AGE_MS);
  if (stale) {
    setTimeout(() => captureProfile().catch(e => log('auto profile capture failed', e)), 1500);
  }
})();

// ----------------------------------------------------------------------------
// Post scanning + button injection
// ----------------------------------------------------------------------------

const processedPosts = new WeakSet();

function scanForPosts() {
  const containers = document.querySelectorAll(CONFIG.POST_CONTAINER_SELECTORS.join(','));
  containers.forEach(post => {
    if (processedPosts.has(post)) return;
    processedPosts.add(post);
    injectDraftButton(post);
  });
}

function injectDraftButton(post) {
  const actionBar = firstMatch(post, CONFIG.ACTION_BAR_SELECTORS);
  if (!actionBar) {
    log('No action bar found for a post — skipping button injection', post);
    return;
  }
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'lcc-draft-btn';
  btn.textContent = '✎ Draft comment';
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    handleDraftClick(post, btn);
  });
  actionBar.appendChild(btn);
}

const observer = new MutationObserver(() => scanForPosts());
observer.observe(document.body, { childList: true, subtree: true });
scanForPosts();

// ----------------------------------------------------------------------------
// Extraction
// ----------------------------------------------------------------------------

async function fetchAsBase64InPage(url, forceMime) {
  const res = await fetch(url);
  const blob = await res.blob();
  const mimeType = forceMime || blob.type || 'application/octet-stream';
  const data = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
  return { mimeType, data };
}

async function extractPost(post) {
  const textEl = firstMatch(post, CONFIG.POST_TEXT_SELECTORS);
  const text = textEl?.innerText?.trim() || post.innerText?.slice(0, 1000) || '';

  const imgEls = Array.from(post.querySelectorAll('img')).filter(img => {
    const w = img.naturalWidth || img.width || 0;
    return w >= CONFIG.MIN_IMAGE_WIDTH && !/profile-displayphoto|ghost-person|company-logo/i.test(img.src || '');
  });
  const imageUrls = [...new Set(imgEls.map(i => i.src))].slice(0, CONFIG.MAX_IMAGES);

  // Video: if it's a blob: URL it only exists in this document, so we must
  // read it here in the content script. Regular https URLs get handed to the
  // background worker, which can fetch cross-origin without CORS trouble.
  let videoInline = null;
  let videoUrl = null;
  let posterUrl = null;

  const videoEl = post.querySelector('video');
  if (videoEl) {
    const src = videoEl.currentSrc || videoEl.src || '';
    posterUrl = videoEl.poster || null;
    if (src.startsWith('blob:')) {
      videoInline = await fetchAsBase64InPage(src, 'video/mp4').catch((e) => {
        log('Could not read blob video in-page', e);
        return null;
      });
    } else if (src) {
      videoUrl = src;
    }
  }

  const commentEls = Array.from(post.querySelectorAll(CONFIG.COMMENT_ITEM_SELECTORS.join(',')))
    .slice(0, CONFIG.MAX_COMMENTS_TO_READ);
  const comments = commentEls.map(c => c.innerText.trim()).filter(Boolean);

  const extracted = { text, imageUrls, videoInline, videoUrl, posterUrl, comments };
  log('Extracted post', extracted);
  return extracted;
}

// ----------------------------------------------------------------------------
// Draft flow
// ----------------------------------------------------------------------------

async function handleDraftClick(post, btn) {
  const originalText = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'Reading post…';
  try {
    const extracted = await extractPost(post);
    const { voiceProfile } = await chrome.storage.local.get('voiceProfile');

    btn.textContent = 'Drafting…';
    const response = await chrome.runtime.sendMessage({
      type: 'DRAFT_COMMENTS',
      payload: { post: extracted, voiceProfile: voiceProfile || null }
    });

    if (response?.error) {
      showError(post, response.error);
    } else {
      showDraftPanel(post, response);
    }
  } catch (err) {
    console.error('[LI Comment Co-Pilot]', err);
    showError(post, err.message || String(err));
  } finally {
    btn.disabled = false;
    btn.textContent = originalText;
  }
}

function removeExistingPanel(post) {
  post.querySelectorAll('[data-lcc-panel]').forEach(el => el.remove());
}

function showError(post, message) {
  removeExistingPanel(post);
  const err = document.createElement('div');
  err.className = 'lcc-error';
  err.dataset.lccPanel = 'true';
  err.textContent = 'Comment Co-Pilot: ' + message;
  post.appendChild(err);
}

function flashCopied(card) {
  const btn = card.querySelector('.lcc-copy-btn');
  const original = btn.textContent;
  btn.textContent = 'Copied ✓';
  setTimeout(() => { btn.textContent = original; }, 1200);
}

function showDraftPanel(post, response) {
  removeExistingPanel(post);

  const panel = document.createElement('div');
  panel.className = 'lcc-panel';
  panel.dataset.lccPanel = 'true';
  panel.innerHTML = `
    <div class="lcc-panel-header">
      <span class="lcc-panel-title">Draft comment</span>
      <button type="button" class="lcc-panel-close" aria-label="Close">×</button>
    </div>
    ${response.analysis ? `<div class="lcc-analysis">${escapeHtml(response.analysis)}</div>` : ''}
    <div class="lcc-drafts"></div>
  `;

  const draftsWrap = panel.querySelector('.lcc-drafts');
  (response.drafts || []).forEach((d, i) => {
    const card = document.createElement('div');
    card.className = 'lcc-draft-card';
    card.innerHTML = `
      <div class="lcc-draft-label">${escapeHtml(d.strategy || `Option ${i + 1}`)}</div>
      <div class="lcc-draft-text" contenteditable="true">${escapeHtml(d.text)}</div>
      <div class="lcc-draft-actions">
        <button type="button" class="lcc-insert-btn">Insert into comment box</button>
        <button type="button" class="lcc-copy-btn">Copy</button>
      </div>
    `;
    card.querySelector('.lcc-insert-btn').addEventListener('click', () => {
      const finalText = card.querySelector('.lcc-draft-text').innerText;
      insertIntoCommentBox(post, finalText);
    });
    card.querySelector('.lcc-copy-btn').addEventListener('click', () => {
      const finalText = card.querySelector('.lcc-draft-text').innerText;
      navigator.clipboard.writeText(finalText);
      flashCopied(card);
    });
    draftsWrap.appendChild(card);
  });

  panel.querySelector('.lcc-panel-close').addEventListener('click', () => panel.remove());
  post.appendChild(panel);
}

async function insertIntoCommentBox(post, text) {
  let editor = firstMatch(post, CONFIG.COMMENT_EDITOR_SELECTORS);

  if (!editor) {
    const commentBtn = firstMatch(post, CONFIG.COMMENT_BUTTON_SELECTORS);
    commentBtn?.click();
    await new Promise(r => setTimeout(r, 500));
    editor = firstMatch(post, CONFIG.COMMENT_EDITOR_SELECTORS);
  }

  if (!editor) {
    alert('Comment Co-Pilot: could not find the comment box automatically. Use Copy instead and paste it in manually.');
    return;
  }

  editor.focus();
  const inserted = document.execCommand('insertText', false, text);
  if (!inserted) {
    // Fallback for editors that ignore execCommand entirely.
    editor.textContent = text;
    editor.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }));
  }
}
