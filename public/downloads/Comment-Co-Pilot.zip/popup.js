async function refreshStatus() {
  const { geminiApiKey, voiceProfile } = await chrome.storage.local.get(['geminiApiKey', 'voiceProfile']);

  const keyEl = document.getElementById('key-status');
  keyEl.textContent = geminiApiKey ? 'Set' : 'Not set';
  keyEl.className = 'pill ' + (geminiApiKey ? 'ok' : 'warn');

  const profEl = document.getElementById('profile-status');
  if (voiceProfile?.capturedAt) {
    const days = Math.floor((Date.now() - voiceProfile.capturedAt) / 86400000);
    profEl.textContent = days === 0 ? 'Captured today' : `Captured ${days}d ago`;
    profEl.className = 'pill ok';
  } else {
    profEl.textContent = 'Not captured';
    profEl.className = 'pill warn';
  }
}

document.getElementById('options-btn').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

document.getElementById('rescan-btn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.includes('linkedin.com/in/')) {
    alert('Open your own LinkedIn profile page first, then click this again.');
    return;
  }
  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => (window.__lccCaptureProfile ? window.__lccCaptureProfile() : null)
  });
  await refreshStatus();
  const captured = results?.[0]?.result;
  alert(captured ? 'Profile captured!' : 'Could not capture — check the page console for details.');
});

refreshStatus();
