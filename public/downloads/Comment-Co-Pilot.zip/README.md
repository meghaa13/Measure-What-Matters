# LinkedIn Comment Co-Pilot

A Chrome extension that reads the LinkedIn post you're currently looking at — text, image, video,
or carousel — plus its existing comments, and drafts 3 neutral, on-brand comment options in your
voice. It fills LinkedIn's comment box for you, but **you always click Post yourself** — nothing
auto-submits.

## Setup (5 minutes)

1. **Get a free Gemini API key** — go to [aistudio.google.com/apikey](https://aistudio.google.com/apikey),
   sign in with a Google account, click "Create API key." No credit card needed.
2. **Load the extension** — open `chrome://extensions`, turn on "Developer mode" (top right),
   click "Load unpacked," and select this folder.
3. **Add your key** — click the extension icon in the toolbar → "Open settings" → paste the key → Save.
4. **Capture your voice** — visit your own LinkedIn profile page once (`linkedin.com/in/your-handle`).
   It auto-captures your headline/about/experience in the background after a couple of seconds. You
   can also trigger this manually any time from the popup ("Re-scan my profile now").
5. **Use it** — open your feed or any single post, and you'll see a small **✎ Draft comment** button
   next to Like/Comment/Share. Click it, wait a few seconds, pick one of the 3 drafts (or edit it
   inline — the text is editable), and click **Insert into comment box**. Review, then click LinkedIn's
   own Post button.

## How it works

- `content.js` runs on linkedin.com. It watches the feed for posts, injects the Draft button, and
  when clicked, reads that post's text, images, video, and visible comments straight out of the DOM.
- `background.js` (the extension's service worker) takes that extracted content plus your cached
  voice profile, fetches any media, and sends one multimodal request to the Gemini API asking for
  3 distinct comment drafts, each following a different, explicit strategy (affirm & extend / ask a
  question / share a data point), so they read as genuinely different rather than three rewordings
  of the same sentence.
- Everything is stored locally via `chrome.storage.local` — your API key and cached profile never
  leave your machine except in the direct call to Google's Gemini endpoint.

## Known limitations (read before you rely on this)

- **LinkedIn's markup changes without notice.** Selectors live in a `CONFIG` object at the top of
  `content.js`. If the Draft button doesn't appear, or the post text/comments come back empty, open
  DevTools → Console — logging is on by default (`CONFIG.DEBUG = true`) and will show you what it
  did and didn't find. Add the missing selector to the relevant list in `CONFIG`.
- **Video is best-effort.** Some LinkedIn videos stream via `blob:` URLs the page created — those
  get read directly. Others load from a CDN URL, which the background worker fetches directly; if
  that fails (blocked, expired signed URL, or over ~18MB) it falls back to just the video's poster
  thumbnail, and the model is told explicitly not to pretend it watched the video.
- **Carousels** are handled as a set of images (LinkedIn renders each slide as an `<img>`), capped
  at 6 slides per post to keep the request size reasonable.
- **Free-tier data use.** Google's free Gemini tier may use what you send (post content, your
  profile info) to improve their models. Enabling billing on the same Google Cloud project removes
  this — see the note in Settings.
- **Comments read are only what's already loaded.** It doesn't auto-click "load more comments" —
  intentionally, to keep the extension's interaction with the page to reading + drafting only.
- **Insertion, not posting.** The extension fills LinkedIn's comment editor via the same technique
  browser writing/grammar tools use for rich-text boxes. If a particular post's editor rejects it,
  use the **Copy** button as a fallback and paste manually.

## Model choice & quota errors

Google's Gemini lineup changes fast — new models ship every few weeks and old ones get sunset
mid-year. Two things worth knowing:

- **The default model is `gemini-3.1-flash-lite`**, a mature, GA, Lite-tier model. An earlier
  version of this extension defaulted to `gemini-2.5-flash`, which turned out to be far enough
  into deprecation that requests for it were landing on `gemini-3.7-flash` instead — a model that
  was one week old at the time, still on introductory pricing, with a much tighter free-tier daily
  quota. That's the fast track to "quota exceeded" errors. Lite-tier, GA models consistently get
  the most generous free limits, so that's the safer default. If Settings → Model ever needs
  updating again, check [ai.google.dev/gemini-api/docs/deprecations](https://ai.google.dev/gemini-api/docs/deprecations)
  for the current recommended model.
- **"503 — high demand"** is Google-side capacity throttling, genuinely temporary. `background.js`
  retries this automatically with backoff (up to 3 retries over ~17s) before giving up.
- **"429 — quota exceeded, check your plan and billing"** is a hard daily/plan limit, not a
  short-term rate limit — retrying seconds later just spends another call against the same
  exhausted quota, so the extension does *not* retry this one. It surfaces immediately instead.
  If you hit this: wait for the daily quota to reset, or enable billing on the Google Cloud
  project behind your key (pay-as-you-go past the free quota, not a subscription).
- You can check exactly what's consuming quota, and which model is actually serving your
  requests, any time at [Google AI Studio → Usage](https://aistudio.google.com/usage).

## A word on LinkedIn's terms

LinkedIn's user agreement restricts bots and automated data collection. This tool is built to stay
on the "personal reading + drafting aid" side of that line: it only acts on posts you're actively
looking at, doesn't scrape in the background, doesn't auto-submit anything, and doesn't do bulk
automation. That said, it's still a browser extension interacting with LinkedIn's DOM in a way they
didn't officially sanction — use your own judgment about how much you rely on it.

## Tweaking the comment strategies

The 3 draft "angles" (affirm & extend / ask a question / share a data point) are defined in
`buildSystemInstruction()` in `background.js`. Edit that prompt directly to change tone, add a 4th
angle, or lean harder into your specific domain — it's plain text, no rebuild needed beyond
reloading the extension in `chrome://extensions`.
