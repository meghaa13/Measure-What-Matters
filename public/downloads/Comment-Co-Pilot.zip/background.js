// ============================================================================
// LinkedIn Comment Co-Pilot — background service worker
//
// Runs the actual Gemini API call. Fetches for LinkedIn media URLs happen
// here (not in the content script) because service workers get a cross-origin
// fetch exemption for domains listed in host_permissions — content-script
// fetches are still bound by the page's own CORS rules.
// ============================================================================

// gemini-2.5-flash is deep enough into deprecation that requests for it
// appear to get silently rerouted to whatever the newest Flash model is
// (seen landing on gemini-3.7-flash, a one-week-old model with a much
// tighter introductory free-tier quota). Pin to a mature, GA Lite model
// instead — Lite tiers consistently get the most generous free-tier limits,
// and this one isn't new enough to be quota-starved.
const DEFAULT_MODEL = 'gemini-3.1-flash-lite';
const MAX_VIDEO_BYTES = 18 * 1024 * 1024; // soft cap — Gemini inline requests have a size ceiling

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'DRAFT_COMMENTS') {
    draftComments(message.payload)
      .then(sendResponse)
      .catch(err => sendResponse({ error: err.message || String(err) }));
    return true; // keep the message channel open for the async response
  }
});

async function draftComments({ post, voiceProfile }) {
  const { geminiApiKey, geminiModel } = await chrome.storage.local.get(['geminiApiKey', 'geminiModel']);
  if (!geminiApiKey) {
    throw new Error('No Gemini API key set yet. Open the extension popup → Open settings → paste a free key from aistudio.google.com.');
  }
  const model = geminiModel || DEFAULT_MODEL;

  const images = [];
  for (const url of post.imageUrls || []) {
    const img = await fetchAsBase64(url).catch(e => { log('image fetch failed', url, e); return null; });
    if (img) images.push(img);
  }

  let video = post.videoInline || null;
  if (!video && post.videoUrl) {
    video = await fetchAsBase64(post.videoUrl, 'video/mp4', MAX_VIDEO_BYTES).catch(e => {
      log('video fetch failed or too large, falling back to poster frame', e);
      return null;
    });
  }
  if (!video && post.posterUrl) {
    const poster = await fetchAsBase64(post.posterUrl).catch(() => null);
    if (poster) images.push(poster);
  }

  const enrichedPost = { text: post.text, comments: post.comments, images, video, hadVideo: !!(post.videoInline || post.videoUrl) && !video };

  const systemInstruction = buildSystemInstruction(voiceProfile);
  const parts = buildParts(enrichedPost);

  const body = {
    systemInstruction: { role: 'system', parts: [{ text: systemInstruction }] },
    contents: [{ role: 'user', parts }],
    generationConfig: {
      temperature: 0.8,
      responseMimeType: 'application/json',
      responseSchema: {
        type: 'OBJECT',
        properties: {
          analysis: { type: 'STRING' },
          drafts: {
            type: 'ARRAY',
            items: {
              type: 'OBJECT',
              properties: {
                strategy: { type: 'STRING' },
                text: { type: 'STRING' }
              },
              required: ['strategy', 'text']
            }
          }
        },
        required: ['analysis', 'drafts']
      }
    }
  };

  const data = await callGemini(model, geminiApiKey, body);
  const rawText = data?.candidates?.[0]?.content?.parts?.map(p => p.text).join('') || '{}';

  let parsed;
  try {
    parsed = JSON.parse(rawText);
  } catch (e) {
    throw new Error('Could not parse Gemini response as JSON: ' + rawText.slice(0, 200));
  }
  return parsed; // { analysis, drafts: [{ strategy, text }, ...] }
}

// 429 (rate limit) and 503 (Google's own "temporary, try again later" overload
// error) are both explicitly transient — retry with backoff instead of
// failing on the first hit. A 429 whose body mentions "quota" is a hard
// daily/plan limit, not a short-term throttle — retrying it just spends
// another call against the same exhausted quota, so that one is NOT retried.
const RETRYABLE_STATUSES = new Set([429, 503]);
const RETRY_DELAYS_MS = [2000, 5000, 10000]; // up to 3 retries, ~17s worst case

async function callGemini(model, apiKey, body) {
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  let lastErrText = '';
  for (let attempt = 0; attempt <= RETRY_DELAYS_MS.length; attempt++) {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (res.ok) return res.json();

    lastErrText = await res.text();
    const isHardQuota = res.status === 429 && /quota/i.test(lastErrText);
    const canRetry = RETRYABLE_STATUSES.has(res.status) && !isHardQuota && attempt < RETRY_DELAYS_MS.length;
    if (!canRetry) {
      throw new Error(`Gemini API error (${res.status}): ${lastErrText.slice(0, 300)}`);
    }
    log(`Gemini ${res.status} (transient) — retrying in ${RETRY_DELAYS_MS[attempt]}ms, attempt ${attempt + 1}/${RETRY_DELAYS_MS.length}`);
    await new Promise(r => setTimeout(r, RETRY_DELAYS_MS[attempt]));
  }
  throw new Error(`Gemini API error: ${lastErrText.slice(0, 300)}`);
}

function buildSystemInstruction(voiceProfile) {
  const name = voiceProfile?.name || 'the user';
  const headline = voiceProfile?.headline || '(not captured yet — visit your LinkedIn profile once so this can be filled in)';
  const about = voiceProfile?.about || '';
  const experience = voiceProfile?.experience || '';

  return `You are helping ${name} write a LinkedIn comment. Their professional voice:
Headline: ${headline}
About: ${about}
Experience: ${experience}

Rules for every draft:
- Neutral, professional tone. Not effusive, not controversial, no generic filler ("Great post!", "So true!", emoji-only reactions).
- 1-3 sentences. Sound like a real person, not marketing copy.
- Add genuine value: a specific observation, a brief related experience, or a real question — never just praise.
- Read the existing comments (if any) and don't repeat the obvious point everyone already made; take a different angle.
- Match the tone/register of the post itself.
- If a video couldn't be read and you're only working from a thumbnail/caption, don't pretend to have watched it — keep the comment general enough to still be accurate.

Produce exactly 3 distinct drafts using these three strategies, in this order:
1. "Affirm & extend" — agree with a specific point and add one concrete detail or implication.
2. "Ask a question" — a genuine, non-generic question that invites the author to elaborate.
3. "Share a data point or experience" — a brief, specific parallel from relevant professional experience (marketing/analytics/CRO domain if it genuinely fits — don't force it otherwise).

Respond with ONLY the JSON described by the response schema. No markdown fences, no commentary outside the JSON.`;
}

function buildParts(post) {
  const parts = [];
  let textBlock = `POST TEXT:\n${post.text || '(no text found)'}\n\n`;

  if (post.comments?.length) {
    textBlock += `EXISTING COMMENTS (for tone + to avoid repetition):\n` +
      post.comments.map((c, i) => `${i + 1}. ${c}`).join('\n') + '\n\n';
  }
  if (post.images?.length) {
    textBlock += `${post.images.length} image(s) from the post are attached below.\n`;
  }
  if (post.video) {
    textBlock += `A video from the post is attached below.\n`;
  } else if (post.hadVideo) {
    textBlock += `Note: this post has a video, but it couldn't be read (too large or blocked) — only the thumbnail image, if any, is attached.\n`;
  }

  parts.push({ text: textBlock });
  (post.images || []).forEach(img => parts.push({ inline_data: { mime_type: img.mimeType, data: img.data } }));
  if (post.video) parts.push({ inline_data: { mime_type: post.video.mimeType, data: post.video.data } });

  return parts;
}

async function fetchAsBase64(url, forceMime, maxBytes) {
  const res = await fetch(url);
  if (!res.ok) throw new Error('fetch failed: ' + res.status);
  const blob = await res.blob();
  if (maxBytes && blob.size > maxBytes) throw new Error('file too large: ' + blob.size + ' bytes');
  const mimeType = forceMime || blob.type || 'image/jpeg';
  const buf = await blob.arrayBuffer();
  const data = arrayBufferToBase64(buf);
  return { mimeType, data };
}

function arrayBufferToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function log(...args) {
  console.log('[LI Comment Co-Pilot bg]', ...args);
}
